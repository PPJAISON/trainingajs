import { Component, OnInit ,EventEmitter,Output} from '@angular/core';

@Component({
  selector: 'app-cockpit',
  templateUrl: './cockpit.component.html',
  styleUrls: ['./cockpit.component.css']
})
export class CockpitComponent implements OnInit {
  @Output('srvCreated') serverCreated= new EventEmitter<{serverName:string,serverContent:string}>();
  @Output('bpCreated') blueprintCreated=new EventEmitter<{bpName:string,bpContent:string}>();
  newServerName = '';
  newServerContent = '';

  constructor() { }

  ngOnInit() {
  }

  onAddServer(serverNameInput:HTMLInputElement) {
    //console.log('serverNameInput->',serverNameInput.value)
    //this.serverCreated.emit({serverName:this.newServerName,serverContent:this.newServerContent});
    this.serverCreated.emit({serverName:serverNameInput.value,serverContent:this.newServerContent});
  }

  onAddBlueprint(serverNameInput:HTMLInputElement) {
    this.blueprintCreated.emit({bpName:serverNameInput.value,bpContent:this.newServerContent});
  }  
}
