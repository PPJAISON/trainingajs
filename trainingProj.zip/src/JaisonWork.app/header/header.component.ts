import { Component } from '@angular/core';
@Component({
    selector:'uc3-app-header',
    templateUrl:'./header.component.html'
})
export class HeaderComponent{

}