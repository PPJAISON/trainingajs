export class Ingredient{
    constructor (public name:string,public amount :number){
    }
}

/*
    public name:string;
    public amount:number;
    constructor (name:string, amount :number){
        
    }*/