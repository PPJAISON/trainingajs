import { Recipe } from './../recipe.model';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recipe-list',
  templateUrl: './recipe-list.component.html',
  styleUrls: ['./recipe-list.component.css']
})
export class RecipeListComponent implements OnInit {
  recipes:Recipe[]=[
    new Recipe('A Test Recipe','This is simply a test by jaison ','https://c1.staticflickr.com/4/3245/2927139301_3b8be38447_b.jpg'),
    new Recipe('2 Test Recipe','This is simply a test by vesta ','https://c.pxhere.com/photos/85/eb/salmon_dill_lemon_plate_eat_friends_party_delicious-757897.jpg!d')
  ];

  constructor() { }

  ngOnInit() {
  }

}
